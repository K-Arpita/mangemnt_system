from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse
from org.models import Organisation, Custom, Role
from django.contrib.auth.decorators import login_required
from django.http import FileResponse

def home(request):
    organisation = Organisation.objects.all()
    custom = Custom.objects.all()
    role = Role.objects.all()
    return render(request, 'home.html',
                  {'organisations': organisation, 'custom': custom, 'role': role})

# def home_view(request):
#     return render(request, 'home.html')