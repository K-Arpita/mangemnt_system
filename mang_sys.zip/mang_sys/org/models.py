from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class Organisation(models.Model):
    name = models.CharField(max_length=150)
    address = models.TextField(max_length=220,blank=True,null=True)
    is_main = models.BooleanField(default=False)

    MAIN_Choice =[
        (True, 'Main Organisation'),
        (False, 'Non-Main Organisation'),
    ]
    is_main =models.BooleanField(choices=MAIN_Choice, default=False)
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name= "Organisation"
        verbose_name_plural ="Organisations"


class Role(models.Model):
    name = models.CharField(max_length=250)  # Example: Admin, Editor, Viewer
    desc= models.TextField(blank=True)

    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name ="Role"
        verbose_name_plural ="Roles"
    
class Custom(AbstractUser):
    organisation =models.ForeignKey(
          'Organisation', on_delete=models.CASCADE, related_name='users',
          null=True, blank=True
    )
    role = models.ForeignKey(
        'Role', on_delete=models.SET_NULL, related_name='users', null=True, blank=True
    )
    def __str__(self):
        return self.username
    
    class Meta:
        verbose_name = "Custom User"
        verbose_name_plural = "Custom Users"



