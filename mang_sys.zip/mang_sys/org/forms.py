# from django import forms
# from .models import organisation
# from django.contrib.auth.forms import UserCreationForm
# from .models import Custom

# class organisationForm(forms.ModelForm):
#     class Meta:
#         model = organisation
#         fields = ['name', 'address', 'is_main']


# class CustomForm(UserCreationForm):
#     class Meta:
#         model = Custom
#         fields = ['username', 'email', 'password1', 'password2', 'organisation', 'role']

from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Organisation, Custom

class OrganisationForm(forms.ModelForm):
    class Meta:
        model = Organisation
        fields = ['name', 'address', 'is_main']

    def clean_name(self):
        name = self.cleaned_data.get('name')
        if Organisation.objects.filter(name=name).exists():
            raise forms.ValidationError("An organization with this name already exists.")
        return name
    
    def clean_address(self):
        address = self.cleaned_data.get('address')
        if len(address) < 10:  # Minimum address length validation
            raise forms.ValidationError("Address is too short. Please provide a valid address.")
        return address

class CustomForm(UserCreationForm):
    class Meta:
        model = Custom
        fields = ['username', 'email', 'password1', 'password2', 'organisation', 'role']

    def clean_organisation(self):
        Organisation = self.cleaned_data.get('organisation')
        if not Organisation:
            raise forms.ValidationError("Organisation is required.")
        return Organisation

    def clean_role(self):
        role = self.cleaned_data.get('role')
        if not role:
            raise forms.ValidationError("Role is required.")
        return role
