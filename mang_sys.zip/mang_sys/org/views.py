from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, FileResponse
from django.contrib.auth.decorators import login_required
from .models import Organisation, Custom, Role
from .forms import OrganisationForm
from django.middleware.csrf import get_token
import os

# Organisation view (test)
def home(request):
    return render(request, 'home.html')

def favicon(request):
    file_path = os.path.join("static", "favicon.ico")
    return FileResponse(open(file_path, "rb"), content_type="image/x-icon")


# List organisations for superuser
@login_required
def organisation_list(request):
    if request.user.is_superuser:
        organisations = Organisation.objects.all()
        return render(request, 'org_list.html', {'organisations': organisations})
    return redirect('home')


# Create new organisation
@login_required
def create_organisation(request):
    if not request.user.is_superuser:
        return redirect('home')
    if request.method == 'POST':
        form = OrganisationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('org_list')  # Redirect to URL name, not template
    else:
        form = OrganisationForm()
    return render(request, 'org_form.html', {'form': form, 'form_title': 'Create Organisation'})


# List users in the organisation
@login_required
def user_list(request):
    # Ensure that the user is only viewing users from their organisation
    users = Custom.objects.filter(Organisation=request.user.organisation)
    return render(request, 'user_list.html', {'users': users})


# Assign role to a user in the organisation
@login_required
def assign_role(request, user_id):
    print("CSRF Token:",get_token(request))
    user = get_object_or_404(Custom, id=user_id, Organisation=request.user.Organisation)
    if request.method == 'POST':
        role_id = request.POST.get('role_id')
        try:
            user.role = Role.objects.get(id=role_id)  # Ensure the role exists
            user.save()
            return redirect('user_list')
        except Role.DoesNotExist:
            return redirect('user_list')  # Or show an error message
    roles = Role.objects.all()
    return render(request, 'assign_role.html', {'user': user, 'roles': roles})
