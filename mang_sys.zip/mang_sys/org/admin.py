from django.contrib import admin
from .models import Organisation, Role, Custom
# Register your models here.

admin.site.register(Organisation)
admin.site.register(Role)
admin.site.register(Custom)