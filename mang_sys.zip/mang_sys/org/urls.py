from django.urls import path
from .import views


urlpatterns = [
    
    path('organisations/', views.organisation_list, name='organisation_list'),
    path('organisations/create/', views.create_organisation, name='create_organisation'),
    path('user/', views.user_list, name='user_list'),
    path('user/<int:user_id>/assign_role/', views.assign_role, name='assign_role'),
]
